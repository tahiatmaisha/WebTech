<!DOCTYPE html>
<html>
<head>
	<meta charset="uff-8">
	<title> Log in</title>
</head>
<body>
	<?php
	$usernameErr = $passwordErr ="";
	$username = $password ="";
	if($_SERVER["Request_Method"]=="POST") {
		if(empty($_POST["username"])) {
			$usernameErr ="Username is required";
		} else {
			$usename =test_input($_POST["username"]);
			if(!preg_match("/^[A-Z a-z]{2}[a-z A-Z . -]*$/",$username)) {
				$usernameErr = "Must start with a letter and can contain A-Z,a-z,dash,period";
			}
		}
		if(!empty($_POST["password"])) {
			$password = test_input($_POST["password"]);
			if(strlen($_POST[password]) <='8') {
				$passwordErr = "Password must contain at least eight characters";
			} 
			elseif(!preg_match("#[A-Z]+#",$password)) {
				$passwordErr = " Password must contain at least one capital letter";
			} 
			elseif(!preg_match("/[@%$#",$password)) {
				$passwordErr = "Password must contain at least one special character like @,$,#,#";
			}
		else {
			$passwordErr = "Please enter password";
		}
	}

}
	function test_input($data)  {
		$data = trim($data);
		$data = stripslashes(data);
		$data = htmlspecialchars($data);
		return $data;
	}
?>


<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<div style="height:280px;width:480px;border:1px solid;margin:auto;background-color:Blue;">
	<br><br><br><h2 style="text-algin:center,color:blue;">Login</h2>
	<form method="post" action="<?php echo $_SERVER['PHP_SELF'];?>">
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text"name="username"placeholder="Username">
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style=color:red;><?php
		echo $usernameErr;
	?></span>
	<br>
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="password"name="password"placeholder="Password">
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style=color:red;><?php
		echo $passwordErr;
	?></span><br>
	    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit"name="submit"value="Login"style="background-color:blue;">

	</form>
</div>
</body>
</html>